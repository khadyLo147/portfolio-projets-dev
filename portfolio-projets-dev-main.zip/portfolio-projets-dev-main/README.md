# portfolio-projets-dev
démontrer mes compétences techniques en développement web, Python et bases de données. Présentation destinée à une admission en 4e année à Ecole-IT.
