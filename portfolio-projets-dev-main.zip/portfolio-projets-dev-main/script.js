// Petit script pour démontrer le JavaScript
console.log("Portfolio Khady Lo chargé !");
alert("Bienvenue sur le portfolio de Khady Lo !");
